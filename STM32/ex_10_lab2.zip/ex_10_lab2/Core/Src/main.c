/* USER CODE BEGIN Header */
/**
  ****************************************************************************
  * @file           : main.c
  * @brief          : Mã nguồn chuẩn tối ưu CPU cho Proteus - Bài 10 Lab 2
  *                   - Ngắt TIM2 chuẩn 10ms (chống quá tải CPU Proteus)
  *                   - 4 LED 7 đoạn & đèn DOT chớp 1Hz
  *                   - Chữ 'A' hiển thị liền khối và cuộn mượt mà
  ****************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* 1. ĐIỀU KHIỂN 4 LED 7 ĐOẠN & DOT (PORT A) */
#define DOT_Pin   GPIO_PIN_4
#define EN0_Pin  GPIO_PIN_6
#define EN1_Pin  GPIO_PIN_7
#define EN2_Pin  GPIO_PIN_8
#define EN3_Pin  GPIO_PIN_9

/* 2. CÁC ĐOẠN LED 7 ĐOẠN (PORT B: PB0 -> PB6) */
#define SEG0_Pin     GPIO_PIN_0
#define SEG1_Pin     GPIO_PIN_1
#define SEG2_Pin     GPIO_PIN_2
#define SEG3_Pin     GPIO_PIN_3
#define SEG4_Pin     GPIO_PIN_4
#define SEG5_Pin     GPIO_PIN_5
#define SEG6_Pin     GPIO_PIN_6

/* 3. CỘT MA TRẬN LED (PORT A: ENM0 -> ENM7 qua ULN2803) */
#define ENM0_Pin  GPIO_PIN_2
#define ENM1_Pin  GPIO_PIN_3
#define ENM2_Pin  GPIO_PIN_10
#define ENM3_Pin  GPIO_PIN_11
#define ENM4_Pin  GPIO_PIN_12
#define ENM5_Pin  GPIO_PIN_13
#define ENM6_Pin  GPIO_PIN_14
#define ENM7_Pin  GPIO_PIN_15

/* 4. HÀNG MA TRẬN LED (PORT B: PB8 -> PB15) */
#define ROW0_Pin  GPIO_PIN_8
#define ROW1_Pin  GPIO_PIN_9
#define ROW2_Pin  GPIO_PIN_10
#define ROW3_Pin  GPIO_PIN_11
#define ROW4_Pin  GPIO_PIN_12
#define ROW5_Pin  GPIO_PIN_13
#define ROW6_Pin  GPIO_PIN_14
#define ROW7_Pin  GPIO_PIN_15
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
const int MAX_LED = 4;
int index_led = 0;
int led_buffer[4] = {0, 0, 0, 0};

int hour = 15;
int minute = 8;
int second = 50;

const int MAX_LED_MATRIX = 8;
int index_led_matrix = 0;

/*
 * Mảng bitmap chữ 'A' liền nét:
 * Cột 0..5 tạo khung chữ hoàn chỉnh, cột 6..7 làm khoảng cách trượt
 */
uint8_t matrix_buffer[8] = {0xFC, 0x12, 0x11, 0x11, 0x12, 0xFC, 0x00, 0x00};

/* Hệ thống 4 Software Timer chạy trên chu kỳ cơ sở 10ms */
int TIMER_CYCLE = 10;

int timer0_counter = 0;
int timer0_flag = 0;

int timer1_counter = 0;
int timer1_flag = 0;

int timer2_counter = 0;
int timer2_flag = 0;

int timer3_counter = 0;
int timer3_flag = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);

/* USER CODE BEGIN PFP */
void display7SEG(int num);
void update7SEG(int index);
void updateClockBuffer(void);

void displayLEDMatrix(uint8_t data);
void updateLEDMatrix(int index);
void shiftLeftMatrix(void);

void setTimer0(int duration);
void setTimer1(int duration);
void setTimer2(int duration);
void setTimer3(int duration);
void timer_run(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void setTimer0(int duration)
{
  timer0_counter = duration / TIMER_CYCLE;
  timer0_flag = 0;
}

void setTimer1(int duration)
{
  timer1_counter = duration / TIMER_CYCLE;
  timer1_flag = 0;
}

void setTimer2(int duration)
{
  timer2_counter = duration / TIMER_CYCLE;
  timer2_flag = 0;
}

void setTimer3(int duration)
{
  timer3_counter = duration / TIMER_CYCLE;
  timer3_flag = 0;
}

void timer_run(void)
{
  if (timer0_counter > 0)
  {
    timer0_counter--;
    if (timer0_counter == 0) timer0_flag = 1;
  }

  if (timer1_counter > 0)
  {
    timer1_counter--;
    if (timer1_counter == 0) timer1_flag = 1;
  }

  if (timer2_counter > 0)
  {
    timer2_counter--;
    if (timer2_counter == 0) timer2_flag = 1;
  }

  if (timer3_counter > 0)
  {
    timer3_counter--;
    if (timer3_counter == 0) timer3_flag = 1;
  }
}

void updateClockBuffer(void)
{
  led_buffer[0] = hour / 10;
  led_buffer[1] = hour % 10;
  led_buffer[2] = minute / 10;
  led_buffer[3] = minute % 10;
}

void display7SEG(int num)
{
  switch (num)
  {
    case 0:
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG1_Pin | SEG2_Pin | SEG3_Pin | SEG4_Pin | SEG5_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOB, SEG6_Pin, GPIO_PIN_SET);
      break;
    case 1:
      HAL_GPIO_WritePin(GPIOB, SEG1_Pin | SEG2_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG3_Pin | SEG4_Pin | SEG5_Pin | SEG6_Pin, GPIO_PIN_SET);
      break;
    case 2:
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG1_Pin | SEG3_Pin | SEG4_Pin | SEG6_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOB, SEG2_Pin | SEG5_Pin, GPIO_PIN_SET);
      break;
    case 3:
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG1_Pin | SEG2_Pin | SEG3_Pin | SEG6_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOB, SEG4_Pin | SEG5_Pin, GPIO_PIN_SET);
      break;
    case 4:
      HAL_GPIO_WritePin(GPIOB, SEG1_Pin | SEG2_Pin | SEG5_Pin | SEG6_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG3_Pin | SEG4_Pin, GPIO_PIN_SET);
      break;
    case 5:
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG2_Pin | SEG3_Pin | SEG5_Pin | SEG6_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOB, SEG1_Pin | SEG4_Pin, GPIO_PIN_SET);
      break;
    case 6:
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG2_Pin | SEG3_Pin | SEG4_Pin | SEG5_Pin | SEG6_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOB, SEG1_Pin, GPIO_PIN_SET);
      break;
    case 7:
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG1_Pin | SEG2_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOB, SEG3_Pin | SEG4_Pin | SEG5_Pin | SEG6_Pin, GPIO_PIN_SET);
      break;
    case 8:
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG1_Pin | SEG2_Pin | SEG3_Pin | SEG4_Pin | SEG5_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOB, SEG6_Pin, GPIO_PIN_RESET);
      break;
    case 9:
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG1_Pin | SEG2_Pin | SEG3_Pin | SEG5_Pin | SEG6_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOB, SEG4_Pin, GPIO_PIN_SET);
      break;
    default:
      HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG1_Pin | SEG2_Pin | SEG3_Pin | SEG4_Pin | SEG5_Pin | SEG6_Pin, GPIO_PIN_SET);
      break;
  }
}

void update7SEG(int index)
{
  switch (index)
  {
    case 0:
      HAL_GPIO_WritePin(GPIOA, EN0_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOA, EN1_Pin | EN2_Pin | EN3_Pin, GPIO_PIN_SET);
      display7SEG(led_buffer[0]);
      break;
    case 1:
      HAL_GPIO_WritePin(GPIOA, EN1_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOA, EN0_Pin | EN2_Pin | EN3_Pin, GPIO_PIN_SET);
      display7SEG(led_buffer[1]);
      break;
    case 2:
      HAL_GPIO_WritePin(GPIOA, EN2_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOA, EN0_Pin | EN1_Pin | EN3_Pin, GPIO_PIN_SET);
      display7SEG(led_buffer[2]);
      break;
    case 3:
      HAL_GPIO_WritePin(GPIOA, EN3_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOA, EN0_Pin | EN1_Pin | EN2_Pin, GPIO_PIN_SET);
      display7SEG(led_buffer[3]);
      break;
    default:
      break;
  }
}

void displayLEDMatrix(uint8_t data)
{
  HAL_GPIO_WritePin(GPIOB, ROW0_Pin, (data & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, ROW1_Pin, (data & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, ROW2_Pin, (data & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, ROW3_Pin, (data & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, ROW4_Pin, (data & 0x10) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, ROW5_Pin, (data & 0x20) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, ROW6_Pin, (data & 0x40) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, ROW7_Pin, (data & 0x80) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void updateLEDMatrix(int index)
{
  /* Tắt tất cả các cột trước để chống bóng mờ */
  HAL_GPIO_WritePin(GPIOA, ENM0_Pin | ENM1_Pin | ENM2_Pin | ENM3_Pin |
                           ENM4_Pin | ENM5_Pin | ENM6_Pin | ENM7_Pin, GPIO_PIN_RESET);

  /* Cập nhật dữ liệu hàng */
  displayLEDMatrix(matrix_buffer[index]);

  /* Bật cột tương ứng */
  switch (index)
  {
    case 0: HAL_GPIO_WritePin(GPIOA, ENM0_Pin, GPIO_PIN_SET); break;
    case 1: HAL_GPIO_WritePin(GPIOA, ENM1_Pin, GPIO_PIN_SET); break;
    case 2: HAL_GPIO_WritePin(GPIOA, ENM2_Pin, GPIO_PIN_SET); break;
    case 3: HAL_GPIO_WritePin(GPIOA, ENM3_Pin, GPIO_PIN_SET); break;
    case 4: HAL_GPIO_WritePin(GPIOA, ENM4_Pin, GPIO_PIN_SET); break;
    case 5: HAL_GPIO_WritePin(GPIOA, ENM5_Pin, GPIO_PIN_SET); break;
    case 6: HAL_GPIO_WritePin(GPIOA, ENM6_Pin, GPIO_PIN_SET); break;
    case 7: HAL_GPIO_WritePin(GPIOA, ENM7_Pin, GPIO_PIN_SET); break;
    default: break;
  }
}

void shiftLeftMatrix(void)
{
  uint8_t temp = matrix_buffer[0];
  for (int i = 0; i < MAX_LED_MATRIX - 1; i++)
  {
    matrix_buffer[i] = matrix_buffer[i + 1];
  }
  matrix_buffer[MAX_LED_MATRIX - 1] = temp;
}
/* USER CODE END 0 */

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_TIM2_Init();

  /* USER CODE BEGIN 2 */
  updateClockBuffer();
  HAL_TIM_Base_Start_IT(&htim2);

  /*
   * Cấu hình thời gian tối ưu cho mô phỏng Proteus:
   * - Timer 0: 1000ms (1s) cập nhật đồng hồ và nhấp nháy đèn DOT
   * - Timer 1: 50ms quét lần lượt 4 LED 7 đoạn
   * - Timer 2: 10ms quét 8 cột ma trận (đúng 100Hz không quá tải CPU)
   * - Timer 3: 200ms cuộn chữ 'A' sang trái
   */
  setTimer0(1000);
  setTimer1(20);
  setTimer2(10);
  setTimer3(1000);
  /* USER CODE END 2 */

  while (1)
  {
    /* TÁC VỤ 1: Quét LED 7 đoạn */
    if (timer1_flag == 1)
    {
      setTimer1(20);
      update7SEG(index_led);
      index_led++;
      if (index_led >= MAX_LED)
      {
        index_led = 0;
      }
    }

    /* TÁC VỤ 2: Cập nhật đồng hồ và đèn DOT */
    if (timer0_flag == 1)
    {
      setTimer0(1000);
      HAL_GPIO_TogglePin(GPIOA, DOT_Pin);

      second++;
      if (second >= 60)
      {
        second = 0;
        minute++;
        if (minute >= 60)
        {
          minute = 0;
          hour++;
          if (hour >= 24)
          {
            hour = 0;
          }
        }
      }
      updateClockBuffer();
    }

    /* TÁC VỤ 3: Quét 8 cột ma trận LED */
    if (timer2_flag == 1)
    {
      setTimer2(10);
      updateLEDMatrix(index_led_matrix);
      index_led_matrix++;
      if (index_led_matrix >= MAX_LED_MATRIX)
      {
        index_led_matrix = 0;
      }
    }

    /* TÁC VỤ 4: Cuộn chữ 'A' sang trái (đồng bộ sau mỗi chu kỳ quét) */
    if (timer3_flag == 1)
    {
      if (index_led_matrix == 0)
      {
        setTimer3(1000);
        shiftLeftMatrix();
      }
    }
  }
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief Khởi tạo TIM2 chu kỳ 10ms (PSC=7999, ARR=9 với xung 8MHz)
  */
static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 9; /* Chu kỳ ngắt đúng 10ms, giảm tải hoàn toàn cho Proteus */
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  HAL_NVIC_SetPriority(TIM2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(TIM2_IRQn);
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_AFIO_CLK_ENABLE();

  __DSB();
  __HAL_AFIO_REMAP_SWJ_DISABLE();

  GPIO_InitStruct.Pin = GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 |
                        GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 |
                        GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13 |
                        GPIO_PIN_14 | GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 |
                        GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_8 |
                        GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 |
                        GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  HAL_GPIO_WritePin(GPIOA, DOT_Pin | EN0_Pin | EN1_Pin | EN2_Pin | EN3_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOA, ENM0_Pin | ENM1_Pin | ENM2_Pin | ENM3_Pin |
                           ENM4_Pin | ENM5_Pin | ENM6_Pin | ENM7_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, SEG0_Pin | SEG1_Pin | SEG2_Pin | SEG3_Pin | SEG4_Pin | SEG5_Pin | SEG6_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, ROW0_Pin | ROW1_Pin | ROW2_Pin | ROW3_Pin |
                           ROW4_Pin | ROW5_Pin | ROW6_Pin | ROW7_Pin, GPIO_PIN_SET);
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2)
  {
    timer_run();
  }
}
/* USER CODE END 4 */

void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif /* USE_FULL_ASSERT */
